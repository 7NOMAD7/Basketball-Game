from .models import Player
from .theGame import rezultat

class Nadimak:
    def __init__(self,ime):
        self.ime=ime

    def izaberi_nadimak(self):
        return self.ime

print("Igra je gotova!")
print("\n")
nadimak=input("Unesi svoj nadimak: ")
instanca_objekta=Nadimak(nadimak).izaberi_nadimak()
igracev_nadimak=instanca_objekta


def igracev_rezultat(broj):
    return broj


rezultat_igre = igracev_rezultat(rezultat)

def operacija(igrac,poeni):
    return dict(name=igrac,points=poeni)

my_dict=operacija(igracev_nadimak,rezultat_igre)

player_name=my_dict['name']
final_points=my_dict['points']


player=Player(p_name=player_name,score=final_points)
player.save()