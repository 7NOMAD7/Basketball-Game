from itertools import cycle
from random import randrange
from tkinter import Canvas, Tk, messagebox, font


sirina_pozadine = 800
visina_pozadine = 600


prozor = Tk()
c = Canvas(prozor, width=sirina_pozadine, height=visina_pozadine,background='black')
c.pack()

boja_lopti = cycle(['orange'])
sirina_lopti = 50
duzina_lopti = 50
poeni_lopti = 10
brzina_lopti = 1000
intervala_lopti = 4000
tezina_igre = 0.95


boja_obruca = 'white'
sirina_obruca = 100
visina_obruca = 200
kalkulacija_1=sirina_pozadine / 2
kalkulacija_2=sirina_obruca / 2
pocetna_pozicija_obruca_x = kalkulacija_1-kalkulacija_2

kalkulacija_visine_1=visina_obruca+30
pocetna_pozicija_obruca_y = visina_pozadine-kalkulacija_visine_1
pocetna_pozicija_obruca_x2 = pocetna_pozicija_obruca_x + sirina_obruca
pocetna_pozicija_obruca_y2 = pocetna_pozicija_obruca_y + visina_obruca
obruc = c.create_arc(pocetna_pozicija_obruca_x, pocetna_pozicija_obruca_y,pocetna_pozicija_obruca_x2, pocetna_pozicija_obruca_y2, start=200, extent=140,style='chord', outline=boja_obruca, width=3)

font_slova = font.nametofont('TkFixedFont')
font_slova.config(size=18)
rezultat = 0
tekst_rezultata = c.create_text(10, 10, anchor='nw', font=font_slova, fill='white',text='Rezultat: ' + str(rezultat))
preostali_zivoti = 3
tekst_za_zivot = c.create_text(sirina_pozadine - 10, 10, anchor='ne', font=font_slova,fill='white', text='Zivoti: ' + str(preostali_zivoti))

lopte = []

def kreiraj_loptu():
    opseg_varijabila = randrange(10, 740)
    vrednost = 40
    nova_lopta = c.create_oval(opseg_varijabila, vrednost, opseg_varijabila + sirina_lopti, vrednost + duzina_lopti, fill=next(boja_lopti), width=0)
    lopte.append(nova_lopta)
    prozor.after(intervala_lopti, kreiraj_loptu)

def putanja_lopti():
    for lopta in lopte:
        (lopta_x, lopta_y, lopta_x2, lopta_y2) = c.coords(lopta)
        c.move(lopta, 0, 10)
        if lopta_y2 > visina_pozadine:
            lopta_bacena(lopta)
    prozor.after(brzina_lopti, putanja_lopti)

def lopta_bacena(lopta):
    lopte.remove(lopta)
    c.delete(lopta)
    gubitak_zivota()
    if preostali_zivoti == 0:
        messagebox.showinfo('Igra zavrsena!', 'Finalni rezultat: ' \
        + str(rezultat))
        prozor.destroy()

def gubitak_zivota():
    global preostali_zivoti
    preostali_zivoti -= 1
    c.itemconfigure(tekst_za_zivot, text='Zivoti: '+ str(preostali_zivoti))

def proveri_pogodak():
    (obruc_x, obruc_y, obruc_x2, obruc_y2) = c.coords(obruc)
    for lopta in lopte:
        (lopta_x, lopta_y, lopta_x2, lopta_y2) = c.coords(lopta)
        if obruc_x < lopta_x and lopta_x2 < obruc_x2 and obruc_y2 - lopta_y2 < 40:
            lopte.remove(lopta)
            c.delete(lopta)
            povecaj_rezultat(poeni_lopti)
    prozor.after(100, proveri_pogodak)


def povecaj_rezultat(poeni):
    global rezultat, brzina_lopti, intervala_lopti
    rezultat += poeni
    brzina_lopti = int(brzina_lopti * tezina_igre)
    intervala_lopti = int(intervala_lopti * tezina_igre)
    c.itemconfigure(tekst_rezultata, text='Rezultat: ' + str(rezultat))

def kretanje_levo(event):
    (x1, y1, x2, y2) = c.coords(obruc)
    if x1 > 0:
        c.move(obruc, -20, 0)

def kretanje_desno(event):
    (x1, y1, x2, y2) = c.coords(obruc)
    if x2 < sirina_pozadine:
        c.move(obruc, 20, 0)

c.bind('<Left>', kretanje_levo)
c.bind('<Right>', kretanje_desno)
c.focus_set()

prozor.after(1000, kreiraj_loptu)
prozor.after(1000, putanja_lopti)
prozor.after(1000, proveri_pogodak)
prozor.mainloop()


